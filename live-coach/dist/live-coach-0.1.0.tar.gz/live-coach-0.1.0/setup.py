# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['live_coach']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.7.1,<4.0.0',
 'mediapipe>=0.9.2.1,<0.10.0.0',
 'opencv-python>=4.7.0.72,<5.0.0.0',
 'pandas>=1.5.3,<2.0.0',
 'pillow>=9.4.0,<10.0.0',
 'requests>=2.28.2,<3.0.0',
 'tqdm>=4.65.0,<5.0.0']

setup_kwargs = {
    'name': 'live-coach',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
